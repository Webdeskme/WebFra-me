<?php
include("protect.php");
$back = test_input($_POST["back"]);
file_put_contents($wd_adminFile . 'back.txt', $back);
header('Location: desktop.php');
?>
