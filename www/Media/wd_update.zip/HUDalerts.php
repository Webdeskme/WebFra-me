<h1>Alerts</h1>
    <form method="post" action="notfySub.php">
        <input type="text" name="post" placeholder="Post here." style="width: 80%;">
        <input type="submit" class="btn btn-success" value="Post">
    </form>
<br><br>
<?php
if ($handle = opendir($wd_root . '/User/' . $_SESSION["user"] . '/Sec/')) {
                while (false !== ($entry = readdir($handle))) {
                    if ($entry != "." && $entry != "..") {
echo "<b>" . $entry . "</b> " . file_get_contents($wd_root . '/User/' . $_SESSION["user"] . '/Sec/' . $entry) . ' <a href="notfySubDelete.php?stamp=' . $entry . '"><i class="text-danger">-Dismiss</i></a><br>';
}}}
?>