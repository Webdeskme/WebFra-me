<?php
session_start();
include("testInput.php");
$post = test_input($_POST["post"]);
$stamp = date("Y-m-d[h:ia]");
file_put_contents($wd_root . '/User/' . $_SESSION["user"] . '/Sec/' . $stamp, $post);
header('Location: desktop.php#tabs-3');
?>
