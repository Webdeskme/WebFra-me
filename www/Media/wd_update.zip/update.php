<?php
session_start();
header("X-Robots-Tag: noIndex, nofollow", true);
if ($_SESSION["Login"] != "YES") {
	  session_destroy();
          header('Location: index.php?test=bad');
}
function test_input($data) {
    if (!empty($data)) {
        $data = trim($data);
   $data = stripslashes($data);
   $data = htmlspecialchars($data);
   return $data;
    }
}
$wd_root = test_input(file_get_contents('path.txt'));
if ($handle = opendir('./')) {
                while (false !== ($entry = readdir($handle))) {
                    if ($entry != "." && $entry != "..") {
						if(!is_dir('./' . $entry)){
							if($entry != "path.txt" && $entry != "update.php" && $entry != "favicon.ico" && $entry != "back.jpg" && $entry != "cred.json" && $entry != "ext.json" && $entry != "feed.xml" && $entry != "wd_market.json"){
								unlink('./' . $entry);
							}
						}
					}
				}
			}
file_put_contents('Tmpfile.zip', fopen('http://webdesk.me/www/Media/wd_update.zip', 'r'));
$zip = new ZipArchive;
$zip->open('./Tmpfile.zip');
$zip->extractTo('./');
$zip->close();
unlink('./Tmpfile.zip');
header('Location: desktop.php');
?>