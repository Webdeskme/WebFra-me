<?php // header.php
// THIS FILE WILL BE CALLED INTO THE  SECTION OF EACH PAGE AND IS WHERE YOU SHOULD INCLUDE STYLE AND SCRIPT CODES.
if(is_file("../../wd_protect.php")){ include_once "../../wd_protect.php"; }
?>