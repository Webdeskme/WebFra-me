<?php
// This is a PHP config file
?>