// start.php
<?php if(is_file("../../wd_protect.php")){ include_once "../../wd_protect.php"; } ?>