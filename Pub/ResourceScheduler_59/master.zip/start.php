<?php // start.php 
// THIS IS THE DEFAULT PAGE FOR YOUR APP. REFER TO WD_FUNCTIONS FOR ENVIRONMENTAL VARIABLES.
if(is_file("../../wd_protect.php")){ include_once "../../wd_protect.php"; }

include_once("config.inc.php");
include("pageHeader.php");
?>
<!-- we're gonna put a calendar here! -->
<div class="calendar" style="height: 100%">
  <div class="container my-5" style="height: 100%">
    <div class="row" style="height: 100%">
      <?php
      $dow = date("w");
      $start_date = time() - (60 * 60 * 24 * ($dow - 1));
      for($x = 0; $x < 5; $x ++){
        
        ?>
        <div class="col">
          <div class="card">
            <div class="card-header">
              <?php echo date("l", $start_date + (60 * 60 * 24 * $x)); ?>
              <br />
            </div>
            <div class="card-body" style="height: 100%">
              <h4 class="card-title"><?php echo date("M j", $start_date + (60 * 60 * 24 * $x)); ?></h4>
            </div>
            <div class="list-group list-group-flush">
              <?php
              for($y = 8; $y < 17; $y ++){
                ?>
                <a href="#" class="list-group-item list-group-item-action text-muted"><?php echo $y ?></a>
                <?php
              }
              ?>
            </div>
          </div>
        </div>
        <?php
        
      }
      ?>
    </div>
  </div>
</div>